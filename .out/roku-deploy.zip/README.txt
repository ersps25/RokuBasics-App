Simple Roku Scene Graph channel containing an empty scene.
This can be enhanced with the following features:
1)      Add grid with video preview (this adds the video grid)
2)      Add loading indicator component