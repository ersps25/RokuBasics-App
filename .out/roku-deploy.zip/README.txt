Simple Roku Scene Graph channel containing following Roku native components
1. Label
2. Rectangle
3. Button
4. Poster
5. Video
6. Focus Handling
7. Event Handling
8. Navigations
9. Data transitions
10. Network Connections

Take the pull, build the code at VS Code or at Eclipse, Install the channel at Roku Device.

Happy Coding!
